
import logging
import os
from aiogram import Bot, Dispatcher, types
from aiogram.types import Message
from aiogram.utils import executor
from dotenv import load_dotenv

load_dotenv()
API_TOKEN = os.getenv("API_TOKEN")

logging.basicConfig(level=logging.INFO)

bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)

@dp.message_handler(commands=['start'])
async def start_command(message: Message):
    await message.reply("Вітаю! Це продовольчий помічник. Оберіть дію:\n/menu — меню\n/checklist — чек-лист")

@dp.message_handler(commands=['menu'])
async def menu_handler(message: Message):
    menu = (
        "Сніданок:\n- Каша гречана – 200 г\n- Яйце – 1 шт\n- Чай з лимоном\n\n"
        "Обід:\n- Борщ – 300 г\n- Картопляне пюре – 200 г\n- Тефтелі – 120 г\n- Компот\n\n"
        "Вечеря:\n- Макарони – 200 г\n- Куряча котлета – 130 г\n- Салат\n"
    )
    await message.answer(menu)

@dp.message_handler(commands=['checklist'])
async def checklist_handler(message: Message):
    checklist = (
        "Чек-лист кухаря:\n"
        "1. Особиста гігієна – [ ]\n"
        "2. Чистота робочих поверхонь – [ ]\n"
        "3. Температура зберігання продуктів – [ ]\n"
        "4. Стан холодильників – [ ]\n"
        "5. Технологічна карта на кожну страву – [ ]"
    )
    await message.answer(checklist)

@dp.message_handler()
async def echo(message: types.Message):
    await message.reply("Не зрозуміла команда. Спробуйте /menu або /checklist.")

if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)
